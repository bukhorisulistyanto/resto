<?php
include_once "library/inc.seslogin.php";
include_once "library/inc.library.php";

if(isset($_POST['btnSimpan'])){
	# Validasi form, jika kosong sampaikan pesan error
	$pesanError = array();
	if (trim($_POST['txtNama'])=="") {
		$pesanError[] = "Data <b>Nama Barang</b> tidak boleh kosong !";		
	}
	if (trim($_POST['txtKeterangan'])=="") {
		$pesanError[] = "Data <b>Nama Barang (lengkap)</b> tidak boleh kosong !";		
	}
	if (trim($_POST['cmbSatuan'])=="KOSONG") {
		$pesanError[] = "Data <b>Satuan Barang</b> belum dipilih !";		
	}
	if (trim($_POST['txtHargaBeli'])=="" or ! is_numeric(trim($_POST['txtHargaBeli']))) {
		$pesanError[] = "Data <b>Harga Beli (Rp.)</b> jual tidak boleh kosong, harus diisi angka  atau 0 !";		
	}
	if (trim($_POST['txtHargaJual'])=="" or ! is_numeric(trim($_POST['txtHargaJual']))) {
		$pesanError[] = "Data <b>Harga Jual (Rp.)</b> jual tidak boleh kosong, harus diisi angka  atau 0 !";		
	}
	if (trim($_POST['cmbKategori'])=="KOSONG") {
		$pesanError[] = "Data <b>Kategori Barang</b> belum dipilih !";		
	}
	if (trim($_POST['cmbSupplier'])=="KOSONG") {
		$pesanError[] = "Data <b>Supplier Barang</b> belum dipilih !";		
	}
	
	# Baca Variabel Form
	$txtBarcode		= $_POST['txtBarcode'];
	
	$txtNama	= $_POST['txtNama'];
	$txtNama	= str_replace("'","&acute;",$txtNama); // menghalangi penulisan tanda petik satu (')
	
	$txtKeterangan	= $_POST['txtKeterangan'];
	$txtKeterangan	= str_replace("'","&acute;",$txtKeterangan); // menghalangi penulisan tanda petik satu (')
	
	$cmbSatuan		= $_POST['cmbSatuan'];
	
	$txtKeterangan	= $_POST['txtKeterangan'];
	$txtKeterangan	= str_replace("'","&acute;",$txtKeterangan); // menghalangi penulisan tanda petik satu (')
	
	$txtHargaBeli	= $_POST['txtHargaBeli'];
	$txtHargaBeli	= str_replace(".","",$txtHargaBeli); // validasi, supaya tanda titik dihilangkan, angka 1.700 = 1700
	
	$txtHargaJual	= $_POST['txtHargaJual'];
	$txtHargaJual	= str_replace(".","",$txtHargaJual); // validasi, supaya tanda titik dihilangkan, angka 1.700 menjadi 1700
	
	$cmbKategori		= $_POST['cmbKategori'];
	$cmbSupplier	= $_POST['cmbSupplier'];
	
	# Validasi Nama barang, jika sudah ada akan ditolak
	$sqlCek="SELECT * FROM barang WHERE nm_barang='$txtNama'";
	$qryCek=mysql_query($sqlCek, $koneksidb) or die ("Eror Query".mysql_error()); 
	if(mysql_num_rows($qryCek)>=1){
		$pesanError[] = "Maaf, Nama Barang <b> $txtNama </b> sudah dipakai, ganti dengan yang lain";
	}


	# JIKA ADA PESAN ERROR DARI VALIDASI
	if (count($pesanError)>=1 ){
		echo "<div class='alert alert-error'>";
		echo "<button type='button' class='close' data-dismiss='alert'>
											<i class='icon-remove'></i></button>

										<strong>
											";
			$noPesan=0;
			foreach ($pesanError as $indeks=>$pesan_tampil) { 
			$noPesan++;
				echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
			} 
		echo "</strong></div> <br>"; 
	}
	else {
		# SIMPAN DATA KE DATABASE. // Jika tidak menemukan error, simpan data ke database
		$kodeBaru	= buatKode("barang", "B");
		$mySql	= "INSERT INTO barang (kd_barang, barcode, nm_barang, keterangan, satuan, harga_beli, harga_jual,
										stok, kd_kategori, kd_supplier) 
							VALUES ('$kodeBaru',
									'$txtBarcode',
									'$txtNama',
									'$txtKeterangan',
									'$cmbSatuan',
									'$txtHargaBeli',
									'$txtHargaJual',
									'0',
									'$cmbKategori',
									'$cmbSupplier')";
		$myQry	= mysql_query($mySql, $koneksidb) or die ("Gagal query".mysql_error());
		if($myQry){
			echo "<meta http-equiv='refresh' content='0; url=?page=Barang-Add'>";
		}
		exit;
	}

} // Penutup POST
	
# MASUKKAN DATA KE VARIABEL
$dataKode	= buatKode("barang", "B");
$barcode	= substr($dataKode, -6, 6); // 6 digit dari kanan (hilangkan karakter simbol B)
$dataBarcode= isset($_POST['txtBarcode']) ? $_POST['txtBarcode'] : $barcode;
$dataNama	= isset($_POST['txtNama']) ? $_POST['txtNama'] : '';
$dataKeterangan	= isset($_POST['txtKeterangan']) ? $_POST['txtKeterangan'] : '';
$dataSatuan		= isset($_POST['cmbSatuan']) ? $_POST['cmbSatuan'] : '';
$dataHargaBeli	= isset($_POST['txtHargaBeli']) ? $_POST['txtHargaBeli'] : '0';
$dataHargaJual	= isset($_POST['txtHargaJual']) ? $_POST['txtHargaJual'] : '0';
$dataKategori	= isset($_POST['cmbKategori']) ? $_POST['cmbKategori'] : '';
$dataSupplier	= isset($_POST['cmbSupplier']) ? $_POST['cmbSupplier'] : '';
?>
<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" name="frmadd" target="_self">
<table width="100%" cellpadding="2" cellspacing="1" class="table-list" style="margin-top:0px;">
	<tr>
	  <th colspan="3"><div align="left">TAMBAH DATA KOLEKSI MENU MAKANAN </div></th>
	</tr>
	<tr>
	  <td width="15%"><b>Kode</b></td>
	  <td width="1%"><b>:</b></td>
	  <td width="84%"><input name="textfield" value="<?php echo $dataKode; ?>" size="14" maxlength="10" readonly="readonly"/></td></tr>
	<tr>
      <td><b>Barcode</b></td>
	  <td><b>:</b></td>
	  <td><input name="txtBarcode" value="<?php echo $dataBarcode; ?>" size="40" maxlength="20" 
	  				onblur="if (value == '') {value = '<?php echo $dataBarcode; ?>'}" 
				 	onfocus="if (value == '<?php echo $dataBarcode; ?>') {value =''}"/></td>
    </tr>
	<tr>
	  <td><b>Nama Menu (30char) </b></td>
      <td><b>:</b></td>
	  <td><input name="txtNama" value="<?php echo $dataNama; ?>" size="40" maxlength="30" />	  
      * Max 30 karakter</td>
    </tr>
	<tr>
	  <td><b>Keterangan</b></td>
	  <td><b>:</b></td>
	  <td><input name="txtKeterangan" value="<?php echo $dataKeterangan; ?>" size="80" maxlength="200" /></td>
	</tr>
	<tr>
	  <td><strong>Satuan</strong></td>
	  <td><b>:</b></td>
	  <td><b>
	    <select name="cmbSatuan">
          <option value="KOSONG">....</option>
          <?php
		  include_once "library/inc.pilihan.php";
          foreach ($satuan as $nilai) {
            if ($dataSatuan == $nilai) {
                $cek=" selected";
            } else { $cek = ""; }
            echo "<option value='$nilai' $cek>$nilai</option>";
          }
          ?>
        </select>
	  </b></td>
    </tr>
	<tr>
      <td><b>Harga Beli (Rp.) </b></td>
	  <td><b>:</b></td>
	  <td><input name="txtHargaBeli" value="<?php echo $dataHargaBeli; ?>" size="20" maxlength="12" 
	  			onblur="if (value == '') {value = '0'}" 
				onfocus="if (value == '0') {value =''}"/></td>
    </tr>
	<tr>
      <td><b>Harga Jual (Rp.) </b></td>
	  <td><b>:</b></td>
	  <td><input name="txtHargaJual" value="<?php echo $dataHargaJual; ?>" size="20" maxlength="12" 
	  			onblur="if (value == '') {value = '0'}" 
				onfocus="if (value == '0') {value =''}"/></td>
    </tr>
	<tr>
      <td><strong>Kategori </strong></td>
	  <td><strong>:</strong></td>
	  <td><select name="cmbKategori">
          <option value="KOSONG">....</option>
          <?php
		$mySql = "SELECT * FROM kategori ORDER BY nm_kategori";
		$myQry = mysql_query($mySql, $koneksidb) or die ("Gagal Query".mysql_error());
		while ($myData = mysql_fetch_array($myQry)) {
		if ($myData['kd_kategori']== $dataKategori) {
			$cek = " selected";
		} else { $cek=""; }
		echo "<option value='$myData[kd_kategori]' $cek>$myData[nm_kategori] </option>";
		}
		?>
      </select></td>
    </tr>
	<tr>
      <td><b>Supplier</b></td>
	  <td><b>:</b></td>
	  <td><b>
        <select name="cmbSupplier">
          <option value="KOSONG">....</option>
          <?php
	  $mySql = "SELECT * FROM supplier ORDER BY kd_supplier";
	  $myQry = mysql_query($mySql, $koneksidb) or die ("Gagal Query".mysql_error());
	  while ($myData = mysql_fetch_array($myQry)) {
	  	if ($dataSupplier == $myData['kd_supplier']) {
			$cek = " selected";
		} else { $cek=""; }
	  	echo "<option value='$myData[kd_supplier]' $cek> $myData[nm_supplier]</option>";
	  }
	  ?>
        </select>
      </b></td>
    </tr>
	<tr><td>&nbsp;</td>
	  <td>&nbsp;</td>
	  <td><input type="submit" name="btnSimpan" value=" SIMPAN " style="cursor:pointer;"></td>
    </tr>
</table>
</form>
