<?php
include_once "../library/inc.connection.php";
include_once "../library/inc.library.php";

if($_GET) {
	# Baca variabel URL
	$noNota = $_GET['noNota'];
	
	# Perintah untuk mendapatkan data dari tabel penjualan
	$mySql = "SELECT penjualan.*, user.nm_user, pelanggan.nm_pelanggan FROM penjualan 
			  LEFT JOIN user ON penjualan.kd_user=user.kd_user
			  LEFT JOIN pelanggan ON penjualan.kd_pelanggan=pelanggan.kd_pelanggan
			  WHERE no_penjualan='$noNota'";
	$myQry = mysql_query($mySql, $koneksidb)  or die ("Query salah : ".mysql_error());
	$myData = mysql_fetch_array($myQry);
}
else {
	echo "Nomor Transaksi Tidak Terbaca";
	exit;
}
?>
<html>
<head>
<title>:: Cetak Penjualan - Toko Serba Ada</title>
<link href="../styles/styles_cetak.css" rel="stylesheet" type="text/css">
</head>
<body>
<h2> PENJUALAN BAJU </h2>
<table width="600" border="0" cellspacing="1" cellpadding="4" class="table-print">
  <tr>
    <td width="139"><b>No. Penjualan </b></td>
    <td width="5"><b>:</b></td>
    <td width="378" valign="top"><strong><?php echo $myData['no_penjualan']; ?></strong></td>
  </tr>
  <tr>
    <td><b>Tgl. Penjualan </b></td>
    <td><b>:</b></td>
    <td valign="top"><?php echo IndonesiaTgl($myData['tgl_penjualan']); ?></td>
  </tr>
  <tr>
    <td><b>Pelanggan</b></td>
    <td><b>:</b></td>
    <td valign="top"><?php echo $myData['nm_pelanggan']; ?></td>
  </tr>
  <tr>
    <td><strong>Keterangan</strong></td>
    <td><b>:</b></td>
    <td valign="top"><?php echo $myData['keterangan']; ?></td>
  </tr>
  <tr>
    <td><strong>Operator</strong></td>
    <td><b>:</b></td>
    <td valign="top"><?php echo $myData['nm_user']; ?></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top">&nbsp;</td>
  </tr>
</table>
<table class="table-list" width="800" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="9" bgcolor="#CCCCCC"><strong>DAFTAR MENU MAKANAN</strong></td>
  </tr>
  <tr>
    <td width="28" rowspan="2" align="center" bgcolor="#F5F5F5"><b>No</b></td>
    <td width="62" rowspan="2" bgcolor="#F5F5F5"><strong>Kode </strong></td>
    <td width="285" rowspan="2" bgcolor="#F5F5F5"><b>Nama Menu</b></td>
    <td colspan="2" align="center" bgcolor="#F5F5F5"><strong>Harga</strong></td>
    <td width="36" rowspan="2" align="center" bgcolor="#F5F5F5"><strong>Disc</strong></td>
    <td width="48" rowspan="2" align="center" bgcolor="#F5F5F5"><b>Jumlah</b></td>
    <td colspan="2" align="center" bgcolor="#F5F5F5"><strong>Total</strong></td>
  </tr>
  <tr>
    <td width="71" align="right" bgcolor="#F5F5F5"><b> Beli(Rp)</b></td>
    <td width="71" align="right" bgcolor="#F5F5F5"><b> Jual(Rp) </b></td>
    <td width="76" align="right" bgcolor="#F5F5F5"><strong> Harga Beli (Rp)</strong> </td>
    <td width="77" align="right" bgcolor="#F5F5F5"><strong> Harga Jual (Rp)</strong></td>
  </tr>
  <?php
  	// deklarasi variabel
	$harga_jualDiskon=0; 
	$grandTotalJual = 0; 
	$grandTotalBeli = 0; 
	$qtyItem = 0;  
	$neto=0;
	
	//  tabel menu 
	$mySql ="SELECT penjualan_item.*, barang.nm_barang FROM penjualan_item
			  LEFT JOIN barang ON penjualan_item.kd_barang=barang.kd_barang 
			  WHERE penjualan_item.no_penjualan='$noNota'
			  ORDER BY penjualan_item.kd_barang";
	$myQry = mysql_query($mySql, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
	$nomor  = 0;  
	while($myData = mysql_fetch_array($myQry)) {
		$nomor++;
		$harga_jualDiskon= $myData['harga_jual'] - ( $myData['harga_jual'] * $myData['diskon'] / 100 );
		$subTotalJual 	= $myData['jumlah'] * $harga_jualDiskon;
		$grandTotalJual	= $grandTotalJual + $subTotalJual;
		
		$subTotalBeli 	= $myData['jumlah'] * $myData['harga_beli'];
		$grandTotalBeli = $grandTotalBeli + $subTotalBeli ;
		
		$qtyItem	= $qtyItem + $myData['jumlah'];
		$neto		= $grandTotalJual - $grandTotalBeli;
	?>
  <tr>
    <td align="center"><?php echo $nomor; ?></td>
    <td><?php echo $myData['kd_barang']; ?></td>
    <td><?php echo $myData['nm_barang']; ?></td>
    <td align="right"><?php echo format_angka($myData['harga_beli']); ?></td>
    <td align="right"><?php echo format_angka($myData['harga_jual']); ?></td>
    <td align="center"><?php echo $myData['diskon']; ?>%</td>
    <td align="center"><?php echo $myData['jumlah']; ?></td>
    <td align="right"><?php echo format_angka($subTotalBeli); ?></td>
    <td align="right"><?php echo format_angka($subTotalJual); ?></td>
  </tr>
  <?php 
}?>
  <tr>
    <td colspan="6" align="right"><b> Grand Total (Rp)  : </b></td>
    <td align="center" bgcolor="#F5F5F5"><strong><?php echo $qtyItem; ?></strong></td>
    <td align="right" bgcolor="#F5F5F5"><strong><?php echo format_angka($grandTotalBeli); ?></strong></td>
    <td align="right" bgcolor="#F5F5F5"><strong><?php echo format_angka($grandTotalJual); ?></strong></td>
  </tr>
  <tr>
    <td colspan="6" align="right"><b>NETO (Rp)   :</b></td>
    <td colspan="3" align="center" bgcolor="#F5F5F5"><strong><?php echo format_angka($neto); ?></strong></td>
  </tr>
</table>
<br/>
<img src="../images/btn_print.png" height="20" onClick="javascript:window.print()" />
</body>
</html>