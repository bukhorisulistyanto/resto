<?php
include_once "../library/inc.connection.php";
include_once "../library/inc.library.php";

# Baca variabel URL
$noNota = $_GET['noNota'];

# Perintah untuk mendapatkan data dari tabel penjualan
$mySql = "SELECT penjualan.*, user.nm_user FROM penjualan
			LEFT JOIN user ON penjualan.kd_user=user.kd_user 
			WHERE no_penjualan='$noNota'";
$myQry = mysql_query($mySql, $koneksidb)  or die ("Query salah : ".mysql_error());
$kolomData = mysql_fetch_array($myQry);
?>
<html>
<head>
<title> :: Aplikasi Kasir Toko Baju Anak Syifa</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles/styles_cetak.css" rel="stylesheet" type="text/css">

<script type="text/javascript">
	window.print();
	window.onfocus=function(){ window.close();}
</script>
</head>
<body onLoad="window.print()">
<table class="table-list" width="430" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td height="87" colspan="6" align="center"><strong>Toko Baju Anak Syifa</strong><br>
      <strong>NPWP/ PKP : </strong>1.111111.11111<br>
      <strong>Tanggal : </strong><?php echo IndonesiaTgl($kolomData['tgl_penjualan']); ?><br>
    Jl. Bapangan Karang Sewu Galur Kulon Progo</td>
  </tr>
  <tr>
    <td colspan="2"><strong>No Nota :</strong> <?php echo $kolomData['no_penjualan']; ?></td>
    <td colspan="4" align="right"><?php echo IndonesiaTgl($kolomData['tgl_penjualan']); ?></td>
  </tr>
  <tr>
    <td width="27" align="center" bgcolor="#F5F5F5"><strong>No</strong></td>
    <td width="195" bgcolor="#F5F5F5"><strong>Daftar Menu </strong></td>
    <td width="41" align="center" bgcolor="#F5F5F5"><strong>Harga</strong></td>
    <td width="34" align="center" bgcolor="#F5F5F5"><strong>Disc</strong></td>
    <td width="27" align="center" bgcolor="#F5F5F5"><strong>Qty</strong></td>
    <td width="75" align="right" bgcolor="#F5F5F5"><strong>Total(Rp)</strong></td>
  </tr>
	<?php
	# Menampilkan List Item barang yang dibeli untuk Nomor Transaksi Terpilih
	$notaSql = "SELECT penjualan_item.*, barang.nm_barang FROM penjualan_item
				LEFT JOIN barang ON penjualan_item.kd_barang=barang.kd_barang 
				WHERE penjualan_item.no_penjualan='$noNota'
				ORDER BY barang.kd_barang ASC";
	$notaQry = mysql_query($notaSql, $koneksidb)  or die ("Query list barang salah : ".mysql_error());
	$nomor   = 0;  $hargaDiskon=0; $totalBayar = 0; $jumlahBarang = 0;  $uangKembali=0;
	while ($notaData = mysql_fetch_array($notaQry)) {
	$nomor++;
		$hargaDiskon= $notaData['harga_jual'] - ( $notaData['harga_jual'] * $notaData['diskon'] / 100 );
		$subSotal 	= $notaData['jumlah'] * $hargaDiskon;
		$totalBayar	= $totalBayar + $subSotal;
		$jumlahBarang	= $jumlahBarang + $notaData['jumlah'];
		$uangKembali= $kolomData['uang_bayar'] - $totalBayar;
	?>
  <tr>
    <td align="center"><?php echo $nomor; ?></td>
    <td><?php echo $notaData['nm_barang']; ?></td>
    <td align="right"><?php echo format_angka($notaData['harga_jual']); ?></td>
    <td align="center"><?php echo $notaData['diskon']; ?>%</td>
    <td align="center"><?php echo $notaData['jumlah']; ?></td>
    <td align="right"><?php echo format_angka($subSotal); ?></td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="3" align="right"><strong>Total Belanja (Rp) : </strong></td>
    <td colspan="3" align="right" bgcolor="#F5F5F5"><strong><?php echo format_angka($totalBayar); ?></strong></td>
  </tr>
  <tr>
    <td colspan="3" align="right"><strong>  Uang Bayar (Rp) : </strong></td>
    <td colspan="3" align="right"><strong><?php echo format_angka($kolomData['uang_bayar']); ?></strong></td>
  </tr>
  <tr>
    <td colspan="3" align="right"><strong>Uang Kembali  (Rp) : </strong></td>
    <td colspan="3" align="right"><strong><?php echo format_angka($uangKembali); ?></strong></td>
  </tr>
  <tr>
    <td colspan="6"><strong>Kasir :</strong> <?php echo $kolomData['nm_user']; ?></td>
  </tr>
</table>
<table width="430" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">** TERIMA KASIH ** </td>
  </tr>
</table>
</body>
</html>