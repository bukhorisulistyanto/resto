<?php
if(isset($_SESSION['SES_ADMIN'])) {
	echo include_once('penjualan/hal_dasboard.php');
}
else if(isset($_SESSION['SES_KASIR'])) {
	echo include_once('penjualan/hal_dasboard.php');	
}
else if(isset($_SESSION['SES_MANAGER'])) {
	echo include_once('laporan_penjualan_barang.php');	
}
else {
	echo "<h2>Selamat datang ........!</h2>";
	echo "<b>Anda belum login, silahkan <a href='index.php' alt='Login'>login </a>untuk mengakses sitem ini ";	
}
?>
