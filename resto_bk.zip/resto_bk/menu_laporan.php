<ul>
	<li><a href="?page=Laporan-User">Laporan Data User</a></li>
	<li><a href="?page=Laporan-Supplier">Laporan Data Supplier</a></li>
	<li><a href="?page=Laporan-Pelanggan">Laporan Data Pelanggan</a></li>
	<li><a href="?page=Laporan-Kategori">Laporan Data Kategori</a></li>
	<li><a href="?page=Laporan-Barang">Laporan Data Barang</a></li>
	<li><a href="?page=Laporan-Barang-per-Kategori">Laporan Barang per Kategori</a></li>
	<li><a href="?page=Laporan-Barang-per-Supplier">Laporan Barang per Supplier</a></li>
	<li><a href="?page=Laporan-Pembelian">Laporan Pembelian</a></li>
	<li><a href="?page=Laporan-Pembelian-per-Periode">Laporan Pembelian per Periode</a></li>
	<li><a href="?page=Laporan-Pembelian-per-Supplier">Laporan Pembelian per Supplier</a></li>
	
	<li><a href="?page=Laporan-Penjualan">Laporan Penjualan</a></li>
	<li><a href="?page=Laporan-Penjualan-per-Periode">Laporan Penjualan per Periode</a></li>
	<li><a href="?page=Laporan-Penjualan-per-Pelanggan">Laporan Penjualan per Pelanggan</a></li>
	<li><a href="?page=Laporan-Penjualan-per-Barang">Laporan Penjualan per Barang</a></li>
</ul>	