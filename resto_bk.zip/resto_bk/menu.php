<?php
if(isset($_SESSION['SES_ADMIN'])){
# JIKA YANG LOGIN LEVEL ADMIN, menu di bawah yang dijalankan
?>
<ul  class="nav nav-list">
	<li ><a href='?page=Halaman-Utama' title='Halaman Utama'><i class="icon-dashboard"></i><span class="menu-text">Home</span></a></li>
	<li><a href='?page=User-Data' title='User Login'><i class="icon-user"></i><span class="menu-text"> Data User</span></a></li>
    <li><a href="#" class="dropdown-toggle"><i class="icon-list"></i><span class="menu-text"> Master Data</span><b class="arrow icon-angle-down"></b></a>
			<ul class="submenu">
            	<li><a href='?page=Supplier-Data'><i class="icon-double-angle-right"></i>Data Supplier</a></li>
                <li><a href='?page=Pelanggan-Data'><i class="icon-double-angle-right"></i>Data Pelanggan</a></li>
                <li><a href='?page=Kategori-Data'><i class="icon-double-angle-right"></i>Data Kategori</a></li>
                <li><a href='?page=Barang-Data'><i class="icon-double-angle-right"></i>Daftar Baju</a></li>
            </ul></li>
	<li><a href='?page=Pencarian-Barang' title='Pencarian Menu Makanan'><i class="icon-search"></i><span class="menu-text"> Pencarian Baju</span></a></li>
    		
	
     <li><a href="#" class="dropdown-toggle"><i class="icon-file-alt"></i><span class="menu-text">Laporan</span><b class="arrow icon-angle-down"></b></a>
    		<ul class="submenu">
            <li><a href="?page=Laporan-User" title='Laporan Data User'><i class="icon-double-angle-right"></i>Data User</a></li>
            <li><a href="?page=Laporan-Supplier"  title='Laporan Data Suppiler'><i class="icon-double-angle-right"></i>Data Suppiler</a></li>
            <li><a href="?page=Laporan-Pelanggan"  title='Laporan Data Pelanggan'><i class="icon-double-angle-right"></i>Data Pelanggan</a></li>
			<li><a href="?page=Laporan-Kategori"  title='Laporan Data Kategory'><i class="icon-double-angle-right"></i>Data Kategori</a></li>
           
            <li><a href="?page=Laporan-Barang-per-Kategori" title='Laporan Data Makanan'><i class="icon-double-angle-right"></i>Daftar Nama Baju</a></li>
                           
             
            
          
          <li><a href=""  title='Laporan Data Penjualan' class="dropdown-toggle"><i class="icon-desktop"></i>
            	<span class="menu-text"> Penjualan</span><b class="arrow icon-angle-down"></b></a>
                <ul class="submenu">
							<li>
								<a href="?page=Laporan-Penjualan" title='Laporan Penjualan'>
									<i class="icon-double-angle-right"></i>Penjualan</a></li>
                            <li>
								<a href="?page=Laporan-Penjualan-per-Periode" title='Laporan Penjualan Per Periode'>
									<i class="icon-double-angle-right"></i>Per Periode</a></li>
                                    <li><a href="?page=Laporan-Penjualan-per-Periode-grafik" title='Laporan Penjualan Per Periode Grafik'><i class="icon-double-angle-right"></i>Penjualan Grafik</a></li>
                            <li>
								<a href="?page=Laporan-Penjualan-per-Pelanggan" title='Laporan Penjualan Per Pelanggan'>
									<i class="icon-double-angle-right"></i>Per Pelanggan</a></li>
                            <li>
								<a href="?page=Laporan-Penjualan-per-Barang" title='Laporan Penjualan Per Barang'>
									<i class="icon-double-angle-right"></i>Per Menu Baju</a></li>
                                    </ul>
                                </li>
                            </ul>
                         </li>
                      </ul>
                  
                
          
            
<?php
}
elseif(isset($_SESSION['SES_KASIR'])){
# JIKA YANG LOGIN LEVEL KASIR, menu di bawah yang dijalankan
?>
<ul  class="nav nav-list">
	<li class="active"><a href='?page' title='Halaman Utama'><i class="icon-dashboard"></i><span class="menu-text">Home</span></a></li>
	   <li><a href='?page=Profile' title='Profile'><i class="icon-user"></i><span class="menu-text">Profile</span></a></li>
     <li><a href='?page=Transaksi-Penjualan' title='Transaksi Penjualan'><i class="icon-shopping-cart"></i><span class="menu-text">Transaksi Penjualan</span></a></li>
</ul>


<?php
}
elseif(isset($_SESSION['SES_MANAGER'])){
# JIKA YANG LOGIN LEVEL KASIR, menu di bawah yang dijalankan
?>
<ul class="nav nav-list">
 <li><a href="#" class="dropdown-toggle"><i class="icon-file-alt"></i><span class="menu-text">Laporan</span><b class="arrow icon-angle-down"></b></a>
    		<ul class="submenu">
            <li><a href="?page=Laporan-User" title='Laporan Data User'><i class="icon-double-angle-right"></i>Data User</a></li>
            <li><a href="?page=Laporan-Supplier"  title='Laporan Data Suppiler'><i class="icon-double-angle-right"></i>Data Suppiler</a></li>
            <li><a href="?page=Laporan-Pelanggan"  title='Laporan Data Pelanggan'><i class="icon-double-angle-right"></i>Data Pelanggan</a></li>
			<li><a href="?page=Laporan-Kategori"  title='Laporan Data Kategory'><i class="icon-double-angle-right"></i>Data Kategory</a></li>
            <li><a href="?page=Laporan-Barang"  title='Laporan Data Menu'><i class="icon-double-angle-right"></i>Daftar Menu Baju</a></li>
            <li><a href="?page=Laporan-Barang-per-Kategori" title='Laporan Data Menu Per kategory'><i class="icon-double-angle-right"></i>Daftar Menu Per Kategory</a></li>
            <li><a href="?page=Laporan-Barang-per-Supplier" title='Laporan Data Menu Per Supplier'><i class="icon-double-angle-right"></i>Daftar Menu Per Supplier</a></li>
            <li><a href="?page=Laporan-Penjualan" title='Laporan Penjualan'><i class="icon-double-angle-right"></i>Penjualan</a></li>
            <li><a href="?page=Laporan-Penjualan-per-Periode" title='Laporan Penjualan Per Periode'><i class="icon-double-angle-right"></i>Penjualan Per Periode</a></li>
            <li><a href="?page=Laporan-Penjualan-per-Periode-grafik" title='Laporan Penjualan Per Periode Grafik'><i class="icon-double-angle-right"></i>Penjualan Grafik</a></li>
            <li><a href="?page=Laporan-Penjualan-per-Pelanggan" title='Laporan Penjualan Per Pelanggan'><i class="icon-double-angle-right"></i>Penjualan Per Pelanggan</a></li>
            <li><a href="?page=Laporan-Penjualan-per-Barang" title='Laporan Penjualan Per Menu'><i class="icon-double-angle-right"></i>Penjualan Per Menu</a></li>
            </ul></li>
</ul>
<?php
}
else {
# JIKA BELUM LOGIN (BELUM ADA SESION LEVEL YG DIBACA)
?>
<ul class="nav nav-list">
	<li><a href='index.php' title='Login System'><i class="icon-unlock"></i><span class="menu-text">Login</span></a></li>	
</ul>
<?php
}
?>