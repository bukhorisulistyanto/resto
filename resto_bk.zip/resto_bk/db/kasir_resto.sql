-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 15 Okt 2017 pada 20.28
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `kasir_resto`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kd_barang` char(7) NOT NULL,
  `barcode` varchar(30) NOT NULL,
  `nm_barang` varchar(30) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `harga_beli` int(12) NOT NULL,
  `harga_jual` int(12) NOT NULL,
  `stok` int(10) NOT NULL,
  `kd_kategori` char(4) NOT NULL,
  `kd_supplier` char(4) NOT NULL,
  `cabang` varchar(50) NOT NULL,
  PRIMARY KEY (`kd_barang`),
  UNIQUE KEY `kd_buku` (`kd_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`kd_barang`, `barcode`, `nm_barang`, `keterangan`, `satuan`, `harga_beli`, `harga_jual`, `stok`, `kd_kategori`, `kd_supplier`, `cabang`) VALUES
('B000009', '000009', 'Sup Iga ', '-', 'Porsi', 50000, 54000, 7, 'K005', 'S001', 'Cabang1'),
('B000007', '000007', 'Motorola BT 421', 'Es Jeruk', 'Gelas', 7000, 8000, 28, 'K001', 'S001', 'Cabang1'),
('B000006', '000006', 'Jus Alpukat', '-', 'Gelas', 12000, 13000, 3, 'K001', 'S001', 'Cabang1'),
('B000005', '000005', 'Kopi Hitam', '-', 'Gelas', 5000, 5000, 4, 'K002', 'S001', 'Cabang2'),
('B000004', '000004', 'Ikan Gurame Saos', '-', 'Porsi', 35000, 40000, 10, 'K004', 'S001', 'Cabang2'),
('B000003', '000003', 'Ayam Sambal Pedas', '-', 'Potong', 20000, 25000, 5, 'K004', 'S001', 'Cabang2'),
('B000002', '000002', 'Nasi Putih', '-', 'Porsi', 5000, 5500, 1, 'K004', 'S001', 'Cabang2'),
('B000001', '000001', 'Nasi Kuning', '-', 'Porsi', 6000, 6500, 88, 'K004', 'S001', 'Cabang2'),
('B000010', '000010', 'Es teh Manis', '-', 'Gelas', 3000, 5000, 0, 'K001', 'S001', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `kd_kategori` char(4) NOT NULL,
  `nm_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`kd_kategori`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`kd_kategori`, `nm_kategori`) VALUES
('K004', 'Makanan'),
('K003', 'Makanan Ringan'),
('K002', 'Kopi'),
('K001', 'Minuman'),
('K005', 'Sup');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `kd_pelanggan` char(5) NOT NULL,
  `nm_pelanggan` varchar(100) NOT NULL,
  `nm_toko` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `no_telepon` varchar(20) NOT NULL,
  PRIMARY KEY (`kd_pelanggan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`kd_pelanggan`, `nm_pelanggan`, `nm_toko`, `alamat`, `no_telepon`) VALUES
('P0004', 'Reguler', '--', '--', '--');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE IF NOT EXISTS `penjualan` (
  `no_penjualan` char(7) NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `kd_pelanggan` char(5) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `uang_bayar` int(12) NOT NULL,
  `kd_user` char(4) NOT NULL,
  `cabang` varchar(50) NOT NULL,
  PRIMARY KEY (`no_penjualan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`no_penjualan`, `tgl_penjualan`, `kd_pelanggan`, `keterangan`, `uang_bayar`, `kd_user`, `cabang`) VALUES
('JL00007', '2017-10-15', 'P0004', '', 102000, 'U001', ''),
('JL00006', '2017-10-15', 'P0004', '', 80000, 'U001', ''),
('JL00005', '2017-10-15', 'P0004', '', 90000, 'U001', ''),
('JL00004', '2017-10-15', 'P0004', '', 100000, 'U001', ''),
('JL00003', '2017-10-15', 'P0004', '', 7000, 'U002', ''),
('JL00002', '2017-10-15', 'P0004', '', 140000, 'U001', ''),
('JL00001', '2017-10-15', 'P0004', '', 140000, 'U001', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan_item`
--

CREATE TABLE IF NOT EXISTS `penjualan_item` (
  `no_penjualan` char(7) NOT NULL,
  `kd_barang` char(7) NOT NULL,
  `kd_kategori` char(7) NOT NULL,
  `harga_beli` int(12) NOT NULL,
  `harga_jual` int(12) NOT NULL,
  `diskon` int(4) NOT NULL,
  `jumlah` int(4) NOT NULL,
  KEY `nomor_penjualan_tamu` (`no_penjualan`,`kd_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penjualan_item`
--

INSERT INTO `penjualan_item` (`no_penjualan`, `kd_barang`, `kd_kategori`, `harga_beli`, `harga_jual`, `diskon`, `jumlah`) VALUES
('JL00004', 'B000006', 'K001', 12000, 13000, 0, 2),
('JL00003', 'B000001', '', 6000, 6500, 0, 1),
('JL00002', 'B000006', 'K001', 12000, 13000, 0, 3),
('JL00002', 'B000001', 'K004', 6000, 6500, 0, 3),
('JL00002', 'B000003', 'K004', 20000, 25000, 0, 3),
('JL00002', 'B000005', 'K002', 5000, 5000, 0, 1),
('JL00001', 'B000006', 'K001', 12000, 13000, 0, 3),
('JL00001', 'B000003', 'K004', 20000, 25000, 0, 3),
('JL00001', 'B000002', 'K004', 5000, 5500, 0, 3),
('JL00004', 'B000003', 'K004', 20000, 25000, 0, 2),
('JL00004', 'B000001', 'K004', 6000, 6500, 0, 2),
('JL00005', 'B000006', 'K001', 12000, 13000, 0, 2),
('JL00005', 'B000003', 'K004', 20000, 25000, 0, 2),
('JL00005', 'B000002', 'K004', 5000, 5500, 0, 2),
('JL00006', 'B000005', 'K002', 5000, 5000, 0, 1),
('JL00006', 'B000010', 'K001', 3000, 5000, 0, 2),
('JL00006', 'B000003', 'K004', 20000, 25000, 0, 2),
('JL00006', 'B000002', 'K004', 5000, 5500, 0, 2),
('JL00007', 'B000010', 'K001', 3000, 5000, 0, 2),
('JL00007', 'B000004', 'K004', 35000, 40000, 0, 2),
('JL00007', 'B000002', 'K004', 5000, 5500, 0, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `kd_supplier` char(4) NOT NULL,
  `nm_supplier` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `no_telepon` varchar(20) NOT NULL,
  PRIMARY KEY (`kd_supplier`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`kd_supplier`, `nm_supplier`, `alamat`, `no_telepon`) VALUES
('S001', 'PT . Resto Food Indonesia', 'Jakarta Selatan', '0895363635');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tmp_penjualan`
--

CREATE TABLE IF NOT EXISTS `tmp_penjualan` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `kd_user` char(4) NOT NULL,
  `kd_barang` char(7) NOT NULL,
  `diskon` int(4) NOT NULL,
  `jumlah` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=143 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `kd_user` char(4) NOT NULL,
  `nm_user` varchar(100) NOT NULL,
  `no_telepon` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `level` varchar(20) NOT NULL DEFAULT 'Kasir',
  `cabang` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`kd_user`, `nm_user`, `no_telepon`, `username`, `password`, `level`, `cabang`) VALUES
('U001', 'Ahmad Andriansyah', '089624037824', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'Cabang1'),
('U002', 'Fitria Prasetya', '081911111111111', 'kasir', 'c7911af3adbd12a035b289556d96470a', 'Kasir', 'Cabang1'),
('U003', 'Fitria Prasetiawati', '081911111111111', 'fitria', 'ef208a5dfcfc3ea9941d7a6c43841784', 'Kasir', 'Cabang1'),
('U004', 'Ahmad Andriansyah', '089624037824', 'Manager', '1d0258c2440a8d19e716292b231e3190', 'Manager', 'Cabang1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_chat_messages`
--

CREATE TABLE IF NOT EXISTS `user_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_content` text NOT NULL,
  `username` varchar(20) NOT NULL,
  `message_time` datetime NOT NULL,
  `recipient` varchar(50) CHARACTER SET utf8 NOT NULL,
  `sudahbaca` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data untuk tabel `user_chat_messages`
--

INSERT INTO `user_chat_messages` (`id`, `message_content`, `username`, `message_time`, `recipient`, `sudahbaca`) VALUES
(17, 'tes1', 'Manager', '2015-10-30 12:07:46', 'admin', 'Y'),
(22, 'test2', 'Manager', '2015-10-30 03:04:33', 'admin', 'N'),
(23, 'test3', 'Manager', '2015-10-30 12:07:10', 'admin', 'Y'),
(25, 'test2', 'kasir', '2015-10-30 00:00:12', 'admin', 'N'),
(26, 'test', 'kasir', '2015-10-30 01:02:13', 'admin', 'Y'),
(27, 'tttttt', 'admin', '0000-00-00 00:00:00', 'kasir', 'Y'),
(28, 'ping', 'admin', '2015-10-30 13:28:16', 'fitria', 'N'),
(29, 'ggggg', 'admin', '2015-10-30 13:56:42', 'kasir', 'Y'),
(30, ' ping test', 'kasir', '2015-10-30 14:08:59', 'Manager', 'N'),
(31, 'ini pesan pertama dari admin', 'admin', '2017-10-07 01:57:19', 'fitria', 'N');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
